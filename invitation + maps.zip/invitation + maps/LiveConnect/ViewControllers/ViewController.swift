//
//  ViewController.swift
//  LiveConnect
//
//  Created by Jake Stone on 2/11/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

