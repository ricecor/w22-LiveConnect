//
//  HomeViewController.swift
//  LiveConnect
//
//  Created by Jake Stone on 2/11/22.
// Home View Controller is the main screen that the user will see after logging in to the app
// it will come from log in or sign up screen
// and have Settings Button in corner for user preferences to be changed

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var SettingsButton: UIButton!
    @IBOutlet weak var CreateButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func SettingsTapped(_ sender: Any) {
    }
    @IBAction func CreateTapped(_ sender: Any) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
